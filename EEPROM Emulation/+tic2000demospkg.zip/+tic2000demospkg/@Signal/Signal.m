
%   Copyright 2013 The MathWorks, Inc.

classdef Signal < mpt.Signal
%tic2000demospkg.Signal  Class definition.

  methods
    function setupCoderInfo(h)
      % Use custom storage classes from this package
      useLocalCustomStorageClasses(h, 'tic2000demospkg');
    end

    %---------------------------------------------------------------------------
    function h = Signal()
      % SIGNAL  Class constructor.
    end % End of constructor

  end % methods
end % classdef
