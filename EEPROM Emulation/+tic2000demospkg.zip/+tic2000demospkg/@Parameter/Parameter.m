%   Copyright 2013 The MathWorks, Inc.

classdef Parameter < mpt.Parameter
%tic2000demospkg.Parameter  Class definition.

  methods
    function setupCoderInfo(h)
      % Use custom storage classes from this package
      useLocalCustomStorageClasses(h, 'tic2000demospkg');
    end

    %---------------------------------------------------------------------------
    function h = Parameter(varargin)
        %PARAMETER  Class constructor.
        
        % Call superclass constructor with variable arguments
        h@mpt.Parameter(varargin{:});
    end % End of constructor

  end % methods
end % classdef
